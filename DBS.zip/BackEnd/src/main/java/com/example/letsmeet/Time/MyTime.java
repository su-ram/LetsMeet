package com.example.letsmeet.Time;

import com.example.letsmeet.User.User;

import lombok.Data;

@Data
public class MyTime {
	
	
	private int[] checkArray;
	private String userId;
	private String meetId;
}
